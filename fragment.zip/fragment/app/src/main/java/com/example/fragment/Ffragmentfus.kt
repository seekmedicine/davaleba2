package com.example.fragment

import androidx.fragment.app.Fragment

class Ffragmentfus:Fragment(R.layout.fragmentfus) {
}