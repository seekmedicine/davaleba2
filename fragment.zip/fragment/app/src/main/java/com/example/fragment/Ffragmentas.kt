package com.example.fragment

import androidx.fragment.app.Fragment

class Ffragmentas:Fragment(R.layout.fragmentas) {
}