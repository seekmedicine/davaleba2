package com.example.fragment

import androidx.fragment.app.Fragment

class Ffragmentus:Fragment(R.layout.fragmentus) {
}